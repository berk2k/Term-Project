package com.example.vetapp.models

data class Result(
    val user: User,
    val token: String,
    val userId: Int
)
