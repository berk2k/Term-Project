package com.example.vetapp.models

data class User(val username: String,val name:String ,val password: String,val role: String)

