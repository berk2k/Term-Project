package com.example.vetapp.models

data class UserProfileResponse(
    val id: Int,
    val userName: String,
    val name: String
)
