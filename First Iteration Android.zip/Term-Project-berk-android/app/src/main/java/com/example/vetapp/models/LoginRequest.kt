package com.example.vetapp.models

data class LoginRequest(val userName: String,
                        val password: String)
