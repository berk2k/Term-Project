package com.example.vetapp.models

data class BookAppointmentRequest(
    val id: Int,
    val appointmentDateTime: String
)
